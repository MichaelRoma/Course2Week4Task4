//
//  ViewController.swift
//  Course2Week4Task4
//
//  Created by Mykhailo Romanovskyi on 12.02.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var textForSending: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .magenta
        
        //Строка ниже сделана, чтоб избежать проверку в методе на nil
        textForSending.text = ""
    }
    
    @IBAction func toViewController3(_ sender: Any) {
        performSegue(withIdentifier: "toThirdVC", sender: nil)
      }
    
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if let distanation = segue.destination as? ViewController3 {
            distanation.text = textForSending.text
        }
    }
}

