//
//  ViewController4.swift
//  Course2Week4Task4
//
//  Created by Mykhailo Romanovskyi on 14.02.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class ViewController4: UIViewController {

    @IBAction func goBack(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
