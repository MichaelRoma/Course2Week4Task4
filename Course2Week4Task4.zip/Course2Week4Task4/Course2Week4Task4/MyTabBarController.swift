//
//  MyTabBarController.swift
//  Course2Week4Task4
//
//  Created by Mykhailo Romanovskyi on 13.02.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class MyTabBarController: UITabBarController, UITabBarControllerDelegate {
    
//    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
//        return true
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        delegate = self
//        viewControllers = [ViewController(), ViewController2()]
//       // setupViewControllers()
//        tabBar.backgroundColor = .green
//        let a = UITabBarItem(title: "ViewController1", image: #imageLiteral(resourceName: "icon1"), tag: 1)
//        let b = UITabBarItem(title: "ViewController2", image: #imageLiteral(resourceName: "icon2"), tag: 2)
//       tabBar.items = [a, b]
    }
//
//    func setupViewControllers() {
//        let first = makeNavViewController(vc: ViewController(), image: #imageLiteral(resourceName: "icon1"), title: "ViewController1")
//        let second = makeNavViewController(vc: ViewController2(), image: #imageLiteral(resourceName: "icon2"), title: "ViewController")
//        viewControllers = [first, second]
//    }
//
//
//    private func makeNavViewController(vc: UIViewController, image: UIImage, title: String) -> UINavigationController {
//        let navController = UINavigationController(rootViewController: vc)
//        navController.tabBarItem.image = image
//        navController.tabBarItem.title = title
//        return navController
//    }
}
