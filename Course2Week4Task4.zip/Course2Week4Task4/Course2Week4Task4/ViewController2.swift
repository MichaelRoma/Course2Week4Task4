//
//  ViewController2.swift
//  Course2Week4Task4
//
//  Created by Mykhailo Romanovskyi on 13.02.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    let childView = ViewController5()
    
    @IBAction func unwindThreeToTwo(segue:UIStoryboardSegue) {}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .lightGray
        setupButtonForChildView()
        setupButtonForViewController4()
    }
}

extension ViewController2 {
    
    private func setupButtonForChildView() {
        
            let x = view.center.x - 100
            let y = view.center.y - 25
            let buttonForChild = UIButton(type: .system)
            buttonForChild.frame = CGRect(x: x, y: y, width: 200.0, height: 50.0)
            buttonForChild.layer.borderWidth = 1.0
            buttonForChild.layer.cornerRadius = 5
            buttonForChild.layer.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            buttonForChild.setTitle("addChildViewController", for: .normal)
            buttonForChild.addTarget(self, action: #selector(setUpChildView), for: .touchUpInside)
            view.addSubview(buttonForChild)
        
    }
    private func setupButtonForViewController4() {
         
            let x = view.center.x - 100
            let y = view.center.y - 100
            let button = UIButton(type: .system)
            button.frame = CGRect(x: x, y: y, width: 200.0, height: 50.0)
            button.layer.borderWidth = 1.0
            button.layer.cornerRadius = 5
            button.layer.borderColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
            button.setTitle("toViewController4", for: .normal)
            button.addTarget(self, action: #selector(presentVC4), for: .touchUpInside)
            view.addSubview(button)
     }
    
    @objc private func presentVC4() {
          print("Hello")
           let destanation = ViewController4()
           present(destanation, animated: true, completion: nil)
        //        destanation.myLebal.text = textForSending.text
    }
    
    @objc private func setUpChildView() {
        
            addChild(childView)
            view.addSubview(childView.view)
            childView.didMove(toParent: self)
            setConstraintForChildView()
        
       }
       
    private func setConstraintForChildView() {

           childView.view.translatesAutoresizingMaskIntoConstraints = false
           childView.view.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50).isActive = true
           childView.view.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -50).isActive = true
           childView.view.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50).isActive = true
           childView.view.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50).isActive = true
       }
    

}
