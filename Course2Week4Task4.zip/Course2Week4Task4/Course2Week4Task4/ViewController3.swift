//
//  ViewController3.swift
//  Course2Week4Task4
//
//  Created by Mykhailo Romanovskyi on 13.02.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    var text: String?
    @IBOutlet weak var myLebal: UILabel!
    @IBAction func pressUnwind(_ sender: Any) {
    //    dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if text != nil {
            myLebal.text = text
        }
    }

}
